          <div id="active" tabindex="-1" role="dialog" aria-labelledby="AtivaConta" aria-hidden="true" class="modal fade text-left">
            <div role="document" class="modal-dialog">
              <div class="modal-content">
                <div class="modal-body">
                  <form method="post" action="">
                    <div class="form-group">
                      <label>Não Tem Nenhum Codigo?</label>
                      <input type="submit" name="pegacodigo" value="Enviar Codigo..." class="form-control btn-info">
                    </div>
                  </form>
                  <form method="post" action="">
                    <div class="form-group">
                      <label>Ja Tenho Codigo:</label>
                      <input type="text" name="codigo" placeholder="####-####-####" value="" class="form-control">
                      <input type="submit" name="active" value="Verificar!" class="form-control btn-info">
                    </div>
                  </form>
                </div>
                <div class="modal-footer">
                  <a data-dismiss="modal"> <i class="fa fa-times"></i> </a>
                </div>
              </div>
            </div>
          </div>